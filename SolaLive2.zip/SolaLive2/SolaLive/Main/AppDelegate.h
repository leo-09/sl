//
//  AppDelegate.h
//  PhoneLive
//
//  Created by liyy on 2018/2/1.
//  Copyright © 2018年 easydarwin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic, assign) BOOL isEdit;

@end

