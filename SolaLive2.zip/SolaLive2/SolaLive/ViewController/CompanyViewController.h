//
//  CompanyViewController.h
//  SolaLive
//
//  Created by liyy on 2018/6/19.
//  Copyright © 2018年 easydarwin. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 单位列表
 */
@interface CompanyViewController : UIViewController<NSXMLParserDelegate>

@property (nonatomic, assign) BOOL isPlay;  // 是否‘马上观看’

@end
