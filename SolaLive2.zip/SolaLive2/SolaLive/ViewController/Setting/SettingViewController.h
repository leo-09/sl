//
//  SettingViewController.h
//  SolaLive
//
//  Created by liyy on 2018/2/26.
//  Copyright © 2018年 easydarwin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UITableViewController

- (instancetype) initWithStoryboard;

@end
