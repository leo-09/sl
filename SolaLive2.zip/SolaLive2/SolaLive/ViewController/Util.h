//
//  Util.h
//  SolaLive
//
//  Created by mac on 2018/6/23.
//  Copyright © 2018年 easydarwin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Util : NSObject

+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;

@end
