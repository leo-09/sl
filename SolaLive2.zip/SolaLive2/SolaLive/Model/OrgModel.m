//
//  OrgModel.m
//  SolaLive
//
//  Created by mac on 2018/6/23.
//  Copyright © 2018年 easydarwin. All rights reserved.
//

#import "OrgModel.h"

@implementation OrgModel

@end
